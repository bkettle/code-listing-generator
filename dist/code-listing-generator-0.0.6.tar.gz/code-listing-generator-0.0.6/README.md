# Code Listing Generator

This will generate a PDF documenting code in the given folder.

To install:

`pip install code-listing-generator`

(requires python3)

To use:

* Navigate to the directory whose files you want to list
* run the command `generate-code-listing`
